# CodeAlpha AutoCAD Internship Tasks (Tech-Oriented)

This ZIP archive includes organized folders for the four tasks interpreted from the AutoCAD internship instruction guide.

> Note: Despite the internship label, these tasks are programming/AI-focused, not traditional CAD (drawing/modeling).

## ✅ Tasks Included
1. **Language Translation Tool** (API & UI based)
2. **Chatbot for FAQs** (NLP)
3. **Music Generation with AI** (RNN/LSTM)
4. **Object Detection and Tracking** (OpenCV, YOLO, SORT)

## 📁 Folder Structure
Each task is organized into its own folder:
- Task1_TranslationTool/
- Task2_ChatbotFAQs/
- Task3_AIMusicGeneration/
- Task4_ObjectTracking/

You may include your code, datasets, results, or screenshots in each folder as part of your internship submission.

© CodeAlpha Internship Program
