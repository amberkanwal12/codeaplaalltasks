# Web Scraping and EDA Project

## Task
Scrape quotes and author names from a public website and perform basic exploratory data analysis (EDA).

## Tools Used
- Python
- BeautifulSoup
- pandas
- requests

## How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the script:
   ```bash
   python main.py
   ```

3. Output:
   - CSV file: `quotes_dataset.csv`
   - Printed EDA summary
