import requests
from bs4 import BeautifulSoup
import pandas as pd

# 1. Web scraping from a test website
url = "http://quotes.toscrape.com"
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

# 2. Extract quotes and authors
quotes = soup.find_all("div", class_="quote")
data = []
for quote in quotes:
    text = quote.find("span", class_="text").get_text()
    author = quote.find("small", class_="author").get_text()
    data.append({"quote": text, "author": author})

# 3. Create DataFrame
df = pd.DataFrame(data)

# 4. Save to CSV
df.to_csv("quotes_dataset.csv", index=False)

# 5. Basic EDA
print("\nSample Data:")
print(df.head())

print("\nAuthors Value Counts:")
print(df['author'].value_counts())

print("\nData Types:")
print(df.dtypes)
