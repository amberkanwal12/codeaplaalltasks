let currentImage = 0;
const images = document.querySelectorAll('.gallery img');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');

function openLightbox() {
  lightbox.style.display = 'flex';
}

function closeLightbox() {
  lightbox.style.display = 'none';
}

function showImage(index) {
  currentImage = index;
  lightboxImg.src = images[currentImage].src;
}

function changeImage(direction) {
  currentImage = (currentImage + direction + images.length) % images.length;
  showImage(currentImage);
}
