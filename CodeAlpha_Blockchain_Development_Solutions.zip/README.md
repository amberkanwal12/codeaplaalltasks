# CodeAlpha Blockchain Development Internship Tasks

This ZIP archive includes structured folders for all blockchain development tasks mentioned in the CodeAlpha internship guide.

## ✅ Tasks Included
1. **Simple Storage Smart Contract**
2. **Multi-Send Smart Contract**
3. **Polling System Smart Contract**
4. **Personal Portfolio (Crypto Locking) Smart Contract**

## 📁 Folder Structure
Each task is organized into a dedicated folder:
- Task1_SimpleStorage/
- Task2_MultiSend/
- Task3_PollingSystem/
- Task4_CryptoLocking/

You can include your Solidity smart contracts, deployment notes, test results, and screenshots in each folder.

© CodeAlpha Internship Program
