This is a placeholder for schema.sql in database.
