This is a placeholder for views.py in backend/django.
