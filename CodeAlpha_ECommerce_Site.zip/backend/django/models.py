This is a placeholder for models.py in backend/django.
