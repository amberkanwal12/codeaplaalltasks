This is a placeholder for urls.py in backend/django.
