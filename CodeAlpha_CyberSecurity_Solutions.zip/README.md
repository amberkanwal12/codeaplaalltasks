# CodeAlpha Cyber Security Internship Tasks

This ZIP archive contains structured folders and starter files/templates for the Cyber Security tasks outlined in the internship document from CodeAlpha.

## ✅ Tasks Included
1. **Basic Network Sniffer** (Python using Scapy/socket)
2. **Phishing Awareness Training** (Presentation or module content)
3. **Secure Coding Review** (Example insecure code + review report)
4. **Network Intrusion Detection System** (Snort config overview)

## 📁 Folder Structure
Each task has its own subfolder:
- Task1_NetworkSniffer/
- Task2_PhishingTraining/
- Task3_SecureCodeReview/
- Task4_IDS/

Modify the templates as needed to complete your submission.

© CodeAlpha Internship Program
