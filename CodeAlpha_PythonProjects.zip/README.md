# 🔷 CodeAlpha Python Internship Projects

This repository contains my completed tasks for the **Python Programming Internship** at **CodeAlpha**.

## ✅ Completed Tasks

### 1. Hangman Game
A simple console-based word guessing game.
- Concepts: Random, Strings, Loops, Conditions
- File: [`hangman.py`](./hangman.py)

### 2. Stock Portfolio Tracker
Tracks total investment using hardcoded stock prices.
- Concepts: Dictionary, User Input, Arithmetic
- File: [`stock_tracker.py`](./stock_tracker.py)

### 3. Email Extractor Script
Extracts all email addresses from a `.txt` file using regex and saves to another file.
- Concepts: Regex, File Handling
- Files: [`extract_emails.py`](./extract_emails.py), [`input.txt`](./input.txt)

### 4. Rule-Based Chatbot
Basic chatbot that replies to greetings and common phrases.
- Concepts: Functions, Conditionals, Loops
- File: [`chatbot.py`](./chatbot.py)

---

## 📌 Instructions Followed
- ✅ Uploaded all tasks to this GitHub repo.
- ✅ Will be sharing a video explanation and tagging [@CodeAlpha](https://www.linkedin.com/company/codealpha-tech/) on LinkedIn.

---

## 🚀 Author
**Your Full Name**  
Python Intern @ CodeAlpha  
[LinkedIn Profile Link]  
[GitHub Profile Link]
