import re

with open('input.txt', 'r') as file:
    content = file.read()

emails = re.findall(r'\b[\w\.-]+@[\w\.-]+\.\w+\b', content)

with open('emails.txt', 'w') as outfile:
    for email in emails:
        outfile.write(email + '\n')

print("📤 Emails extracted and saved to 'emails.txt'")
