stock_prices = {
    "AAPL": 180,
    "TSLA": 250,
    "GOOG": 150,
    "MSFT": 300
}

portfolio = {}
total_investment = 0

print("📈 Stock Portfolio Tracker")

while True:
    stock = input("Enter stock symbol (or 'done' to finish): ").upper()
    if stock == 'DONE':
        break
    if stock in stock_prices:
        quantity = int(input(f"Enter quantity for {stock}: "))
        investment = quantity * stock_prices[stock]
        portfolio[stock] = investment
        total_investment += investment
    else:
        print("⚠️ Invalid stock symbol!")

print("\n🧾 Portfolio Summary:")
for stock, value in portfolio.items():
    print(f"{stock}: ${value}")

print(f"\n💰 Total Investment: ${total_investment}")
