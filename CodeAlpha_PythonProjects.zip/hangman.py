import random

words = ['apple', 'banana', 'grapes', 'mango', 'peach']
chosen_word = random.choice(words)
guessed_letters = []
tries = 6

print("🎯 Welcome to Hangman Game!")

while tries > 0:
    display_word = ''.join([letter if letter in guessed_letters else '_' for letter in chosen_word])
    print("\nWord:", display_word)

    if '_' not in display_word:
        print("🎉 You guessed the word correctly!")
        break

    guess = input("Guess a letter: ").lower()

    if guess in guessed_letters:
        print("⚠️ Already guessed!")
        continue

    guessed_letters.append(guess)

    if guess not in chosen_word:
        tries -= 1
        print(f"❌ Wrong guess! Tries left: {tries}")

if tries == 0:
    print(f"💀 Game Over! The word was '{chosen_word}'")
