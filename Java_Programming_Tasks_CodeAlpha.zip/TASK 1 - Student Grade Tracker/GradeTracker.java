This is a placeholder for GradeTracker.java in TASK 1 - Student Grade Tracker.
