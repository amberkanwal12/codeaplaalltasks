This is a placeholder for README.md in TASK 1 - Student Grade Tracker.
