This is a placeholder for README.md in TASK 2 - Stock Trading Platform.
