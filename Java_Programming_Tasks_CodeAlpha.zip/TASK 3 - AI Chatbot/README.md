This is a placeholder for README.md in TASK 3 - AI Chatbot.
