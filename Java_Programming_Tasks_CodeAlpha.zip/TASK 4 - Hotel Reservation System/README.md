This is a placeholder for README.md in TASK 4 - Hotel Reservation System.
