This is a placeholder for HotelReservation.java in TASK 4 - Hotel Reservation System.
