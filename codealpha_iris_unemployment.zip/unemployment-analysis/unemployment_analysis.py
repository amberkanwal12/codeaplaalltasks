# Unemployment Data Analysis using Pandas and Matplotlib
import pandas as pd
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv("unemployment.csv")
print(df.head())

# Plot unemployment trends by country
for country in df["Country"].unique():
    data = df[df["Country"] == country]
    plt.plot(data["Year"], data["Unemployment Rate"], label=country)

plt.title("Unemployment Rate by Year")
plt.xlabel("Year")
plt.ylabel("Unemployment Rate (%)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("unemployment_plot.png")
plt.show()
