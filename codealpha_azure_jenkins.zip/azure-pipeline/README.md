# Azure CI/CD Pipeline Project

## Objectives
- Build an automated CI/CD pipeline using Azure Pipelines
- Use Azure Container Registry (ACR) for storing Docker images
- Deploy web applications to Azure App Service automatically
- Monitor pipeline for smooth execution

## Files
- azure-pipelines.yml: Pipeline definition file
- Dockerfile: Container setup for app
