#!/bin/bash
# Replace the following variables with your actual Jenkins master details
JENKINS_URL="http://your-jenkins-url"
AGENT_NAME="remote-agent-1"
SECRET_KEY="your-agent-secret"
WORK_DIR="/home/jenkins/agent"

# Create working directory
mkdir -p $WORK_DIR
cd $WORK_DIR

# Download agent.jar from Jenkins master
wget $JENKINS_URL/jnlpJars/agent.jar

# Run Jenkins agent
java -jar agent.jar -jnlpUrl $JENKINS_URL/computer/$AGENT_NAME/jenkins-agent.jnlp -secret $SECRET_KEY -workDir "$WORK_DIR"
