# Jenkins Remoting Setup

## Objectives
- Connect remote Jenkins nodes (slaves) using secure remoting
- Distribute build load across multiple machines

## Requirements
- Java installed on remote machine
- Jenkins master setup and running
- JNLP (Java Web Start Agent) setup on remote node

## Files
- connect-agent.sh: Script to connect Jenkins agent remotely
